package com.cinebox.app

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import androidx.compose.ui.viewinterop.AndroidView

private val Bg = Color(0xFF090B10)
private val Panel = Color(0xFF151923)
private val Accent = Color(0xFF9C7BFF)
private val Muted = Color(0xFF9BA3B5)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                background = Bg, surface = Panel, primary = Accent,
                onBackground = Color.White, onSurface = Color.White
            )) {
                CineBoxScreen()
            }
        }
    }
}

data class Rendition(val label: String, val height: Int, val url: String)
data class StreamSource(val id: String, val name: String, val renditions: List<Rendition>)

/**
 * Only pass sources supplied by a backend/provider you are authorized to use.
 * Quality options are derived from the actual rendition metadata, never invented.
 */
object SourceResolver {
    fun availableQualities(source: StreamSource?): List<String> =
        source?.renditions.orEmpty()
            .filter { it.url.startsWith("https://") && Uri.parse(it.url).host != null }
            .map { it.label }
            .distinct()

    fun resolve(source: StreamSource?, requestedQuality: String): Rendition? {
        val valid = source?.renditions.orEmpty()
            .filter { it.url.startsWith("https://") && Uri.parse(it.url).host != null }
        return valid.firstOrNull { it.label == requestedQuality }
            ?: valid.maxByOrNull { it.height }
    }
}

@Composable
private fun CineBoxScreen() {
    // Empty by default: no fabricated URLs or unverified third-party streams.
    val sources = remember { emptyList<StreamSource>() }
    var selectedSource by remember { mutableStateOf("Source A") }
    var preferredQuality by remember { mutableStateOf("4K") }
    var notice by remember { mutableStateOf("No authorized stream source is configured yet.") }
    var showPlayer by remember { mutableStateOf(false) }
    val selected = sources.firstOrNull { it.name == selectedSource }
    val qualities = SourceResolver.availableQualities(selected)
    val rendition = SourceResolver.resolve(selected, preferredQuality)

    Column(
        modifier = Modifier.fillMaxSize().background(Bg)
    ) {
        Box(
            modifier = Modifier.fillMaxWidth().height(210.dp)
                .background(Brush.verticalGradient(listOf(Color(0xFF312456), Bg)))
                .padding(22.dp)
        ) {
            Column(modifier = Modifier.align(Alignment.BottomStart)) {
                Text("CINEBOX", color = Accent, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
                Spacer(Modifier.height(8.dp))
                Text("Your next movie night.", fontSize = 27.sp, fontWeight = FontWeight.ExtraBold)
                Text("One library. Clear source choices.", color = Muted, fontSize = 13.sp)
            }
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(18.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Text("FEATURED", color = Accent, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                Spacer(Modifier.height(7.dp))
                Text("Movie playback prototype", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text("Source selection and quality are driven by real provider metadata.", color = Muted, fontSize = 13.sp)
            }
            item {
                Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("STREAM SOURCE", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
                        listOf("Source A", "Source B", "Source C").forEach { sourceName ->
                            Row(
                                Modifier.fillMaxWidth().clickable { selectedSource = sourceName }
                                    .background(if (selectedSource == sourceName) Color(0xFF28213D) else Color.Transparent, RoundedCornerShape(10.dp))
                                    .padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                RadioButton(selected = selectedSource == sourceName, onClick = { selectedSource = sourceName })
                                Spacer(Modifier.width(8.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(sourceName, fontWeight = FontWeight.SemiBold)
                                    Text(if (sources.any { it.name == sourceName }) "Available" else "Not configured", color = Muted, fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }
            }
            item {
                Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("VIDEO QUALITY", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
                        if (qualities.isEmpty()) {
                            Text("4K, 1080p, 720p and Auto are hidden until a configured source advertises those renditions.", color = Muted, fontSize = 13.sp)
                            Text("Preferred quality: 4K", color = Accent, fontWeight = FontWeight.SemiBold)
                        } else {
                            qualities.forEach { q ->
                                Row(Modifier.fillMaxWidth().clickable { preferredQuality = q }.padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                                    RadioButton(selected = preferredQuality == q, onClick = { preferredQuality = q })
                                    Text(q)
                                }
                            }
                        }
                    }
                }
            }
            item {
                Button(
                    onClick = {
                        if (rendition == null) {
                            notice = "Playback unavailable: connect a trusted backend that returns authorized HTTPS stream URLs and actual quality metadata."
                            showPlayer = false
                        } else {
                            notice = "Opening ${rendition.label} stream."
                            showPlayer = true
                        }
                    },
                    modifier = Modifier.fillMaxWidth().height(54.dp),
                    enabled = rendition != null,
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(Icons.Default.PlayArrow, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("PLAY", fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
                }
            }
            item {
                OutlinedButton(
                    onClick = { notice = "Source check complete: no authorized provider is configured in this prototype." },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(Icons.Default.Refresh, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Check sources")
                }
            }
            item {
                Text(notice, color = if (rendition == null) Color(0xFFFFC46B) else Muted, fontSize = 13.sp)
            }
            if (showPlayer && rendition != null) {
                item {
                    PlayerPanel(url = rendition.url)
                }
            }
            item {
                Text("Prototype only · Add your own authorized stream provider to enable playback.", color = Muted, fontSize = 11.sp)
            }
        }
    }
}

@Composable
private fun PlayerPanel(url: String) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val player = remember(url) {
        ExoPlayer.Builder(context).build().apply { setMediaItem(MediaItem.fromUri(url)); prepare(); playWhenReady = true }
    }
    DisposableEffect(player) { onDispose { player.release() } }
    AndroidView(
        factory = { ctx -> PlayerView(ctx).apply { this.player = player } },
        modifier = Modifier.fillMaxWidth().height(230.dp)
    )
}
